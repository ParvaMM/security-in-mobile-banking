package com.bank.izbank.UserInfo;

import java.util.Stack;

public interface UserTypeState {

    public void TypeChange(User user);

}
